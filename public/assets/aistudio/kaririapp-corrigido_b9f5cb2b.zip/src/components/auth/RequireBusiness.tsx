import React from 'react';
import { Navigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LoadingState } from '../common/LoadingState';

export const RequireBusiness: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <LoadingState type="spinner" message="Verificando permissões de acesso..." />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const allowed = (user.role === 'business' || user.role === 'admin') && (user.status === 'active' || !user.status);

  if (!allowed) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-3">
        <h2 className="text-xl font-black text-gray-900">Área exclusiva para donos de negócio</h2>
        <p className="text-xs text-gray-500 leading-relaxed">
          Para gerenciar um local, reivindique-o na página do estabelecimento. Após a aprovação da nossa equipe,
          esta área é liberada.
        </p>
        <Link to="/perfil" className="inline-block px-5 py-2.5 rounded-xl bg-gray-900 text-white font-bold text-xs">
          Voltar para o Perfil
        </Link>
      </div>
    );
  }

  return <>{children}</>;
};
