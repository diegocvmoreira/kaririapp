import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MailCheck, MailWarning } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { authApi } from '../../services/api/auth';

/**
 * Aviso para contas com e-mail não confirmado + feedback do link de confirmação
 * (o backend redireciona para /perfil?email_verificado=1|0).
 */
export const EmailVerificationBanner: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [sending, setSending] = useState(false);
  const verifiedParam = searchParams.get('email_verificado');

  useEffect(() => {
    if (verifiedParam === null) return;
    if (verifiedParam === '1') {
      setFeedback({ ok: true, text: 'E-mail confirmado com sucesso! Agora você pode avaliar locais e reivindicar negócios.' });
      void refreshUser();
    } else {
      setFeedback({ ok: false, text: 'Link de confirmação inválido ou expirado. Solicite um novo link.' });
    }
    const next = new URLSearchParams(searchParams);
    next.delete('email_verificado');
    setSearchParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [verifiedParam]);

  const handleResend = async () => {
    setSending(true);
    try {
      const res = await authApi.resendVerification();
      setFeedback({ ok: true, text: res.message });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Não foi possível reenviar agora.';
      setFeedback({ ok: false, text: message });
    } finally {
      setSending(false);
    }
  };

  const needsVerification = !!user && !user.email_verified_at;

  if (!feedback && !needsVerification) return null;

  const isOk = feedback ? feedback.ok : false;

  return (
    <div
      role="status"
      className={`text-xs font-semibold py-2 px-4 flex flex-wrap items-center justify-center gap-2 text-center ${
        isOk ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-900'
      }`}
    >
      {isOk ? <MailCheck className="w-4 h-4" /> : <MailWarning className="w-4 h-4" />}
      <span>
        {feedback
          ? feedback.text
          : `Confirme seu e-mail (${user?.email}) para avaliar locais e reivindicar negócios.`}
      </span>
      {needsVerification && !(feedback && feedback.ok && verifiedParam === '1') && (
        <button
          type="button"
          onClick={handleResend}
          disabled={sending}
          className="underline font-bold disabled:opacity-50"
        >
          {sending ? 'Enviando...' : 'Reenviar link'}
        </button>
      )}
    </div>
  );
};
