import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Store, CalendarPlus, Trash2, Save } from 'lucide-react';
import {
  businessApi,
  BusinessEvent,
  BusinessPlace,
  BusinessPlaceUpdate,
} from '../services/api/business';
import { LoadingState } from '../components/common/LoadingState';

const EVENT_STATUS_LABEL: Record<string, string> = {
  pending: 'Em análise',
  published: 'Publicado',
  rejected: 'Rejeitado',
  draft: 'Rascunho',
  archived: 'Arquivado',
};

const FIELDS: { key: keyof BusinessPlaceUpdate; label: string; type?: 'textarea' | 'url' }[] = [
  { key: 'short_description', label: 'Resumo (até 500 caracteres)' },
  { key: 'description', label: 'Descrição completa', type: 'textarea' },
  { key: 'address', label: 'Endereço' },
  { key: 'neighborhood', label: 'Bairro' },
  { key: 'zipcode', label: 'CEP' },
  { key: 'phone', label: 'Telefone' },
  { key: 'whatsapp', label: 'WhatsApp' },
  { key: 'website', label: 'Site (https://...)', type: 'url' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'facebook', label: 'Facebook' },
  { key: 'opening_hours', label: 'Horário de funcionamento', type: 'textarea' },
];

const inputClass =
  'w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#DE1F2A]/40';

export const BusinessDashboardPage: React.FC = () => {
  const [places, setPlaces] = useState<BusinessPlace[]>([]);
  const [events, setEvents] = useState<BusinessEvent[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [eventForm, setEventForm] = useState({ title: '', start_date: '', start_time: '', description: '' });

  const selected = places.find((p) => p.id === selectedId) ?? null;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [myPlaces, myEvents] = await Promise.all([businessApi.listMyPlaces(), businessApi.listMyEvents()]);
      setPlaces(myPlaces);
      setEvents(myEvents);
      setSelectedId((current) => current ?? myPlaces[0]?.id ?? null);
    } catch (err) {
      setMessage({ ok: false, text: err instanceof Error ? err.message : 'Erro ao carregar seus dados.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!selected) return;
    const next: Record<string, string> = {};
    FIELDS.forEach(({ key }) => {
      const value = selected[key as keyof BusinessPlace];
      next[key] = value === null || value === undefined ? '' : String(value);
    });
    setForm(next);
  }, [selected]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    setSaving(true);
    setMessage(null);
    try {
      const payload: BusinessPlaceUpdate = {};
      FIELDS.forEach(({ key }) => {
        (payload as Record<string, string | null>)[key] = form[key]?.trim() ? form[key].trim() : null;
      });
      const updated = await businessApi.updatePlace(selected.id, payload);
      setPlaces((list) => list.map((p) => (p.id === updated.id ? { ...p, ...updated } : p)));
      setMessage({ ok: true, text: 'Informações do local salvas com sucesso.' });
    } catch (err) {
      setMessage({ ok: false, text: err instanceof Error ? err.message : 'Não foi possível salvar.' });
    } finally {
      setSaving(false);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    setMessage(null);
    try {
      await businessApi.createEvent({
        place_id: selected.id,
        title: eventForm.title.trim(),
        start_date: eventForm.start_date,
        start_time: eventForm.start_time || null,
        description: eventForm.description.trim() || null,
      });
      setEventForm({ title: '', start_date: '', start_time: '', description: '' });
      setMessage({ ok: true, text: 'Evento enviado para análise. Ele ficará público após a aprovação da equipe Kariri.' });
      setEvents(await businessApi.listMyEvents());
    } catch (err) {
      setMessage({ ok: false, text: err instanceof Error ? err.message : 'Não foi possível criar o evento.' });
    }
  };

  const handleDeleteEvent = async (id: number) => {
    if (!window.confirm('Excluir este evento?')) return;
    try {
      await businessApi.deleteEvent(id);
      setEvents((list) => list.filter((ev) => ev.id !== id));
    } catch (err) {
      setMessage({ ok: false, text: err instanceof Error ? err.message : 'Não foi possível excluir.' });
    }
  };

  if (loading) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <LoadingState type="spinner" message="Carregando seu negócio..." />
      </div>
    );
  }

  return (
    <div className="px-4 py-6 space-y-6 max-w-3xl mx-auto">
      <header className="space-y-1">
        <h1 className="text-2xl font-black text-gray-900 flex items-center gap-2">
          <Store className="w-6 h-6 text-[#DE1F2A]" /> Meu negócio
        </h1>
        <p className="text-xs text-gray-500">
          Edite as informações de contato e descrição dos seus locais e divulgue eventos. Nome, categoria,
          localização e selo de verificação são gerenciados pela equipe Kariri.
        </p>
      </header>

      {message && (
        <div
          role="status"
          className={`rounded-xl px-4 py-3 text-xs font-semibold ${
            message.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'
          }`}
        >
          {message.text}
        </div>
      )}

      {places.length === 0 ? (
        <div className="bg-white rounded-3xl border border-gray-100 p-6 text-center space-y-2">
          <p className="text-sm font-semibold text-gray-900">Você ainda não possui locais vinculados.</p>
          <p className="text-xs text-gray-500">
            Abra a página de um estabelecimento e use “Reivindicar este local”. Após a aprovação, ele aparece aqui.
          </p>
          <Link to="/explorar" className="inline-block text-xs font-bold text-[#DE1F2A] underline">
            Explorar locais
          </Link>
        </div>
      ) : (
        <>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {places.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedId(p.id)}
                className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold border transition ${
                  p.id === selectedId
                    ? 'bg-[#DE1F2A] text-white border-[#DE1F2A]'
                    : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>

          {selected && (
            <form onSubmit={handleSave} className="bg-white rounded-3xl border border-gray-100 p-5 space-y-4">
              <h2 className="text-sm font-black text-gray-900">
                {selected.name}{' '}
                <span className="text-[10px] font-bold text-gray-400">
                  {selected.city_name} · {selected.category_name}
                </span>
              </h2>
              {FIELDS.map(({ key, label, type }) => (
                <label key={key} className="block space-y-1">
                  <span className="text-xs font-semibold text-gray-700">{label}</span>
                  {type === 'textarea' ? (
                    <textarea
                      rows={4}
                      className={inputClass}
                      value={form[key] ?? ''}
                      onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    />
                  ) : (
                    <input
                      type={type === 'url' ? 'url' : 'text'}
                      className={inputClass}
                      value={form[key] ?? ''}
                      onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    />
                  )}
                </label>
              ))}
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#DE1F2A] text-white text-xs font-bold hover:bg-[#C51620] disabled:opacity-50"
              >
                <Save className="w-4 h-4" /> {saving ? 'Salvando...' : 'Salvar alterações'}
              </button>
            </form>
          )}

          {selected && (
            <section className="bg-white rounded-3xl border border-gray-100 p-5 space-y-4">
              <h2 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <CalendarPlus className="w-4 h-4 text-[#DE1F2A]" /> Divulgar evento em {selected.name}
              </h2>
              <form onSubmit={handleCreateEvent} className="grid gap-3 sm:grid-cols-2">
                <input
                  required
                  placeholder="Título do evento"
                  className={`${inputClass} sm:col-span-2`}
                  value={eventForm.title}
                  onChange={(e) => setEventForm((f) => ({ ...f, title: e.target.value }))}
                />
                <input
                  required
                  type="date"
                  className={inputClass}
                  value={eventForm.start_date}
                  onChange={(e) => setEventForm((f) => ({ ...f, start_date: e.target.value }))}
                />
                <input
                  type="time"
                  className={inputClass}
                  value={eventForm.start_time}
                  onChange={(e) => setEventForm((f) => ({ ...f, start_time: e.target.value }))}
                />
                <textarea
                  rows={3}
                  placeholder="Descrição"
                  className={`${inputClass} sm:col-span-2`}
                  value={eventForm.description}
                  onChange={(e) => setEventForm((f) => ({ ...f, description: e.target.value }))}
                />
                <button
                  type="submit"
                  className="sm:col-span-2 px-5 py-2.5 rounded-xl bg-gray-900 text-white text-xs font-bold hover:bg-black"
                >
                  Enviar para análise
                </button>
              </form>
            </section>
          )}

          <section className="space-y-2">
            <h2 className="text-sm font-black text-gray-900">Meus eventos</h2>
            {events.length === 0 && <p className="text-xs text-gray-500">Nenhum evento cadastrado.</p>}
            {events.map((ev) => (
              <div
                key={ev.id}
                className="bg-white rounded-2xl border border-gray-100 px-4 py-3 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="text-sm font-bold text-gray-900 truncate">{ev.title}</p>
                  <p className="text-[11px] text-gray-500">
                    {ev.start_date} · {EVENT_STATUS_LABEL[ev.status] ?? ev.status}
                  </p>
                </div>
                <button
                  type="button"
                  aria-label={`Excluir evento ${ev.title}`}
                  onClick={() => handleDeleteEvent(ev.id)}
                  className="p-2 rounded-lg text-gray-400 hover:text-[#DE1F2A] hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </section>
        </>
      )}
    </div>
  );
};
