import { apiClient } from './config';

/** Campos que o dono do negócio pode editar (espelha UpdateBusinessPlaceRequest no backend). */
export interface BusinessPlace {
  id: number;
  name: string;
  slug: string;
  city_name?: string | null;
  category_name?: string | null;
  status: string;
  verified: boolean;
  short_description: string;
  description: string;
  address: string | null;
  neighborhood: string | null;
  zipcode: string | null;
  phone: string | null;
  whatsapp: string | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  opening_hours: string | null;
  price_level: number;
}

export type BusinessPlaceUpdate = Partial<
  Pick<
    BusinessPlace,
    | 'short_description' | 'description' | 'address' | 'neighborhood' | 'zipcode' | 'phone'
    | 'whatsapp' | 'website' | 'instagram' | 'facebook' | 'opening_hours' | 'price_level'
  >
>;

export interface BusinessEvent {
  id: number;
  title: string;
  slug: string;
  description: string | null;
  start_date: string | null;
  end_date: string | null;
  start_time: string | null;
  end_time: string | null;
  price: number;
  ticket_url: string | null;
  status: 'draft' | 'pending' | 'published' | 'rejected' | 'archived' | string;
}

export interface BusinessEventInput {
  place_id: number;
  title: string;
  description?: string | null;
  start_date: string;
  end_date?: string | null;
  start_time?: string | null;
  end_time?: string | null;
  price?: number | null;
  ticket_url?: string | null;
}

export const businessApi = {
  async listMyPlaces(): Promise<BusinessPlace[]> {
    const res = await apiClient<{ data: BusinessPlace[] }>('/business/places');
    return res.data;
  },

  async updatePlace(id: number, updates: BusinessPlaceUpdate): Promise<BusinessPlace> {
    const res = await apiClient<{ data: BusinessPlace }>(`/business/places/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
    return res.data;
  },

  async listMyEvents(): Promise<BusinessEvent[]> {
    const res = await apiClient<{ data: BusinessEvent[] }>('/business/events');
    return res.data;
  },

  async createEvent(input: BusinessEventInput): Promise<BusinessEvent> {
    const res = await apiClient<{ data: BusinessEvent }>('/business/events', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    return res.data;
  },

  async deleteEvent(id: number): Promise<void> {
    await apiClient<unknown>(`/business/events/${id}`, { method: 'DELETE' });
  },
};
