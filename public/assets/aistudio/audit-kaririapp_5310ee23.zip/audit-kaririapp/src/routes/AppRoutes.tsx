import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { MainLayout } from '../layouts/MainLayout';
import { HomePage } from '../pages/HomePage';
import { ExplorePage } from '../pages/ExplorePage';
import { FavoritesPage } from '../pages/FavoritesPage';
import { ProfilePage } from '../pages/ProfilePage';
import { LoginPage } from '../pages/LoginPage';
import { RegisterPage } from '../pages/RegisterPage';
import { RequireAdmin } from '../components/auth/RequireAdmin';
import { LoadingState } from '../components/common/LoadingState';
import { NotFoundPage } from '../pages/NotFoundPage';

// Code Splitting / Lazy Loading (Audit Item 9)
const MapPage = lazy(() => import('../pages/MapPage').then((m) => ({ default: m.MapPage })));
const PlaceDetailPage = lazy(() => import('../pages/PlaceDetailPage').then((m) => ({ default: m.PlaceDetailPage })));
const EventDetailPage = lazy(() => import('../pages/EventDetailPage').then((m) => ({ default: m.EventDetailPage })));
const CategoryDetailPage = lazy(() => import('../pages/CategoryDetailPage').then((m) => ({ default: m.CategoryDetailPage })));
const AdminDashboardPage = lazy(() => import('../pages/AdminDashboardPage').then((m) => ({ default: m.AdminDashboardPage })));
const LegalPrivacyPage = lazy(() => import('../pages/LegalPrivacyPage').then((m) => ({ default: m.LegalPrivacyPage })));
const ForgotPasswordPage = lazy(() => import('../pages/ForgotPasswordPage').then((m) => ({ default: m.ForgotPasswordPage })));
const ResetPasswordPage = lazy(() => import('../pages/ResetPasswordPage').then((m) => ({ default: m.ResetPasswordPage })));
const CreatePlacePage = lazy(() => import('../pages/CreatePlacePage').then((m) => ({ default: m.CreatePlacePage })));
const CreateEventPage = lazy(() => import('../pages/CreateEventPage').then((m) => ({ default: m.CreateEventPage })));
const MyContributionsPage = lazy(() => import('../pages/MyContributionsPage').then((m) => ({ default: m.MyContributionsPage })));

const PageSuspenseFallback = () => (
  <div className="min-h-[60vh] flex items-center justify-center p-6">
    <LoadingState type="spinner" message="Carregando..." />
  </div>
);

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        {/* Main tabs */}
        <Route path="/" element={<HomePage />} />
        <Route path="/explorar" element={<ExplorePage />} />
        <Route
          path="/mapa"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <MapPage />
            </Suspense>
          }
        />
        <Route path="/favoritos" element={<FavoritesPage />} />
        <Route path="/perfil" element={<ProfilePage />} />

        {/* Cadastro / Sugestão pública de locais e eventos */}
        <Route
          path="/novo-local"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <CreatePlacePage />
            </Suspense>
          }
        />
        <Route
          path="/locais/novo"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <CreatePlacePage />
            </Suspense>
          }
        />
        <Route
          path="/novo-evento"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <CreateEventPage />
            </Suspense>
          }
        />
        <Route
          path="/eventos/novo"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <CreateEventPage />
            </Suspense>
          }
        />
        <Route
          path="/minhas-contribuicoes"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <MyContributionsPage />
            </Suspense>
          }
        />

        {/* Dynamic detail pages */}
        <Route
          path="/locais/:slug"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <PlaceDetailPage />
            </Suspense>
          }
        />
        <Route
          path="/eventos/:slug"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <EventDetailPage />
            </Suspense>
          }
        />
        <Route
          path="/categorias/:slug"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <CategoryDetailPage />
            </Suspense>
          }
        />

        {/* Protected Admin panel */}
        <Route
          path="/admin"
          element={
            <RequireAdmin>
              <Suspense fallback={<PageSuspenseFallback />}>
                <AdminDashboardPage />
              </Suspense>
            </RequireAdmin>
          }
        />

        {/* Auth routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/cadastro" element={<RegisterPage />} />
        <Route
          path="/esqueci-senha"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <ForgotPasswordPage />
            </Suspense>
          }
        />
        <Route
          path="/redefinir-senha"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <ResetPasswordPage />
            </Suspense>
          }
        />

        {/* Legal & Compliance routes */}
        <Route
          path="/privacidade"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <LegalPrivacyPage />
            </Suspense>
          }
        />
        <Route
          path="/cookies"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <LegalPrivacyPage />
            </Suspense>
          }
        />
        <Route
          path="/termos"
          element={
            <Suspense fallback={<PageSuspenseFallback />}>
              <LegalPrivacyPage />
            </Suspense>
          }
        />

        {/* Catch-all real 404 */}
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
};
